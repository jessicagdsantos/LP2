﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PPESOIDEAL
{
    public partial class lblGenero : Form
    {
        double Peso, Altura, pesoIdeal;

        public lblGenero()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void lblGenero_Load(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (double.TryParse(mskTxtAltura.Text.Replace(".", ","), out Altura) &&
                    double.TryParse(mskTxtPeso.Text.Replace("." , ","), out Peso))
            {
                if (btnMulher.Checked == true)
                {
                    pesoIdeal = (Altura * 62.1) - 44.7;

                    mskTxtPesoIdeal.Text = pesoIdeal.ToString();

                }
                else
                {
                    pesoIdeal = (Altura * 72.7) - 58;

                    mskTxtPesoIdeal.Text = pesoIdeal.ToString();

                }

            }
            else
                MessageBox.Show("Números inválidos!!");

            if (pesoIdeal > Convert.ToDouble(mskTxtPeso.Text))
                MessageBox.Show("Coma bastante massas e doces!");
            else if (pesoIdeal == Convert.ToDouble(mskTxtPeso.Text))
                MessageBox.Show("Você está no peso ideal!");
            else
                MessageBox.Show("Regime obrigatório já!");

        }

        private void lblPeso_Click(object sender, EventArgs e)
        {

        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            mskTxtAltura.Clear();
            mskTxtPeso.Clear();
            mskTxtPesoIdeal.Clear();


        }
    }
}
