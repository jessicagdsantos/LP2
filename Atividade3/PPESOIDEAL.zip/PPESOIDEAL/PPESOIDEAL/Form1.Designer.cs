﻿namespace PPESOIDEAL
{
    partial class lblGenero
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.btnMulher = new System.Windows.Forms.RadioButton();
            this.btnHomem = new System.Windows.Forms.RadioButton();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnOut = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mskTxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtPesoIdeal = new System.Windows.Forms.MaskedTextBox();
            this.lblPesoIdeal = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(144, 74);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(57, 13);
            this.lblPeso.TabIndex = 1;
            this.lblPeso.Text = "Peso atual";
            this.lblPeso.Click += new System.EventHandler(this.lblPeso_Click);
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(144, 133);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(91, 13);
            this.lblAltura.TabIndex = 1;
            this.lblAltura.Text = "Altura (em metros)";
            // 
            // btnMulher
            // 
            this.btnMulher.AutoSize = true;
            this.btnMulher.Checked = true;
            this.btnMulher.Location = new System.Drawing.Point(47, 19);
            this.btnMulher.Name = "btnMulher";
            this.btnMulher.Size = new System.Drawing.Size(57, 17);
            this.btnMulher.TabIndex = 2;
            this.btnMulher.TabStop = true;
            this.btnMulher.Text = "Mulher";
            this.btnMulher.UseVisualStyleBackColor = true;
            // 
            // btnHomem
            // 
            this.btnHomem.AutoSize = true;
            this.btnHomem.Location = new System.Drawing.Point(47, 59);
            this.btnHomem.Name = "btnHomem";
            this.btnHomem.Size = new System.Drawing.Size(61, 17);
            this.btnHomem.TabIndex = 2;
            this.btnHomem.Text = "Homem";
            this.btnHomem.UseVisualStyleBackColor = true;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(147, 277);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(346, 277);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(548, 277);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(75, 23);
            this.btnOut.TabIndex = 4;
            this.btnOut.Text = "Sair";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMulher);
            this.groupBox1.Controls.Add(this.btnHomem);
            this.groupBox1.Location = new System.Drawing.Point(548, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // mskTxtPeso
            // 
            this.mskTxtPeso.Location = new System.Drawing.Point(253, 71);
            this.mskTxtPeso.Name = "mskTxtPeso";
            this.mskTxtPeso.Size = new System.Drawing.Size(100, 20);
            this.mskTxtPeso.TabIndex = 6;
            // 
            // mskTxtAltura
            // 
            this.mskTxtAltura.Location = new System.Drawing.Point(253, 130);
            this.mskTxtAltura.Name = "mskTxtAltura";
            this.mskTxtAltura.Size = new System.Drawing.Size(100, 20);
            this.mskTxtAltura.TabIndex = 6;
            // 
            // mskTxtPesoIdeal
            // 
            this.mskTxtPesoIdeal.Location = new System.Drawing.Point(253, 198);
            this.mskTxtPesoIdeal.Name = "mskTxtPesoIdeal";
            this.mskTxtPesoIdeal.Size = new System.Drawing.Size(100, 20);
            this.mskTxtPesoIdeal.TabIndex = 6;
            // 
            // lblPesoIdeal
            // 
            this.lblPesoIdeal.AutoSize = true;
            this.lblPesoIdeal.Location = new System.Drawing.Point(144, 201);
            this.lblPesoIdeal.Name = "lblPesoIdeal";
            this.lblPesoIdeal.Size = new System.Drawing.Size(57, 13);
            this.lblPesoIdeal.TabIndex = 1;
            this.lblPesoIdeal.Text = "Peso Ideal";
            // 
            // lblGenero
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mskTxtPesoIdeal);
            this.Controls.Add(this.mskTxtAltura);
            this.Controls.Add(this.mskTxtPeso);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnOut);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblPesoIdeal);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lblPeso);
            this.Name = "lblGenero";
            this.Text = "\'";
            this.Load += new System.EventHandler(this.lblGenero_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.RadioButton btnMulher;
        private System.Windows.Forms.RadioButton btnHomem;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox mskTxtPeso;
        private System.Windows.Forms.MaskedTextBox mskTxtAltura;
        private System.Windows.Forms.MaskedTextBox mskTxtPesoIdeal;
        private System.Windows.Forms.Label lblPesoIdeal;
    }
}

