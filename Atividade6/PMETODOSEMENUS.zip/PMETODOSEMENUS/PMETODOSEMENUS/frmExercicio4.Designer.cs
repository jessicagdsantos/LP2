﻿namespace PMETODOSEMENUS
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.btnAlfa = new System.Windows.Forms.Button();
            this.btnPrimeiroEspaco = new System.Windows.Forms.Button();
            this.btnNum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(140, 40);
            this.rchTxt.MaxLength = 100;
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(430, 96);
            this.rchTxt.TabIndex = 0;
            this.rchTxt.Text = "";
            // 
            // btnAlfa
            // 
            this.btnAlfa.Location = new System.Drawing.Point(482, 199);
            this.btnAlfa.Margin = new System.Windows.Forms.Padding(4);
            this.btnAlfa.Name = "btnAlfa";
            this.btnAlfa.Size = new System.Drawing.Size(88, 93);
            this.btnAlfa.TabIndex = 10;
            this.btnAlfa.Text = "Alfabéticos";
            this.btnAlfa.UseVisualStyleBackColor = true;
            this.btnAlfa.Click += new System.EventHandler(this.btnAlfa_Click);
            // 
            // btnPrimeiroEspaco
            // 
            this.btnPrimeiroEspaco.Location = new System.Drawing.Point(319, 199);
            this.btnPrimeiroEspaco.Margin = new System.Windows.Forms.Padding(4);
            this.btnPrimeiroEspaco.Name = "btnPrimeiroEspaco";
            this.btnPrimeiroEspaco.Size = new System.Drawing.Size(88, 93);
            this.btnPrimeiroEspaco.TabIndex = 11;
            this.btnPrimeiroEspaco.Text = "Posição do Primeiro Espaço em Branco";
            this.btnPrimeiroEspaco.UseVisualStyleBackColor = true;
            this.btnPrimeiroEspaco.Click += new System.EventHandler(this.btnPrimeiroEspaco_Click);
            // 
            // btnNum
            // 
            this.btnNum.Location = new System.Drawing.Point(140, 199);
            this.btnNum.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(88, 93);
            this.btnNum.TabIndex = 12;
            this.btnNum.Text = "Numericos";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAlfa);
            this.Controls.Add(this.btnPrimeiroEspaco);
            this.Controls.Add(this.btnNum);
            this.Controls.Add(this.rchTxt);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt;
        private System.Windows.Forms.Button btnAlfa;
        private System.Windows.Forms.Button btnPrimeiroEspaco;
        private System.Windows.Forms.Button btnNum;
    }
}