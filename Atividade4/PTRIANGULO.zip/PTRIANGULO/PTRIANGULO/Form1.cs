﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTRIANGULO
{
    public partial class Form1 : Form
    {
        double Lado1, Lado2, Lado3;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLado1.Text, out Lado1) && double.TryParse(txtLado2.Text, out Lado2) &&
                double.TryParse(txtLado3.Text, out Lado3))

            {
                if ((Lado1 < Lado2 + Lado3) && (Lado2 < Lado1 + Lado3) &&
                (Lado3 < Lado1 + Lado2))

                {
                    if (Lado1 == Lado2 && Lado1 == Lado3)
                        MessageBox.Show("É um triângulo equilátero");

                    else if (Lado1 == Lado2 || Lado1 == Lado3 || Lado2 == Lado3)
                        MessageBox.Show("É um triângulo isósceles");

                    else
                        MessageBox.Show("É um triângulo escaleno");
                }
                else
                    MessageBox.Show("Não forma triângulo!");
            }

            else
                MessageBox.Show("Números inválidos!!!");

        }
    }
}
