﻿namespace PSALARIO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.MaskedTextBox();
            this.txtSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtNFilhos = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtnFem = new System.Windows.Forms.RadioButton();
            this.rdbtnMasc = new System.Windows.Forms.RadioButton();
            this.checkEstadoCivil = new System.Windows.Forms.CheckBox();
            this.btnVDesc = new System.Windows.Forms.Button();
            this.txtDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.txtAliINSS = new System.Windows.Forms.MaskedTextBox();
            this.txtDescIRRF = new System.Windows.Forms.MaskedTextBox();
            this.txtAliIRRF = new System.Windows.Forms.MaskedTextBox();
            this.txtSAlFamilia = new System.Windows.Forms.MaskedTextBox();
            this.txtSalLiquido = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnOut = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(194, 12);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 0;
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(194, 53);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalBruto.TabIndex = 0;
            // 
            // txtNFilhos
            // 
            this.txtNFilhos.Location = new System.Drawing.Point(194, 96);
            this.txtNFilhos.Name = "txtNFilhos";
            this.txtNFilhos.Size = new System.Drawing.Size(100, 20);
            this.txtNFilhos.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nome do funcionário";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Salário bruto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(91, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Número de filhos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 241);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Alíquota INSS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Alíquota IRRF";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(99, 293);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Salário Família";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(498, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Desconto INSS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(498, 232);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Desconto IRRF";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtnFem);
            this.groupBox1.Controls.Add(this.rdbtnMasc);
            this.groupBox1.Location = new System.Drawing.Point(501, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 112);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // rdbtnFem
            // 
            this.rdbtnFem.AutoSize = true;
            this.rdbtnFem.Location = new System.Drawing.Point(26, 29);
            this.rdbtnFem.Name = "rdbtnFem";
            this.rdbtnFem.Size = new System.Drawing.Size(67, 17);
            this.rdbtnFem.TabIndex = 5;
            this.rdbtnFem.TabStop = true;
            this.rdbtnFem.Text = "Feminino";
            this.rdbtnFem.UseVisualStyleBackColor = true;
            // 
            // rdbtnMasc
            // 
            this.rdbtnMasc.AutoSize = true;
            this.rdbtnMasc.Location = new System.Drawing.Point(26, 70);
            this.rdbtnMasc.Name = "rdbtnMasc";
            this.rdbtnMasc.Size = new System.Drawing.Size(73, 17);
            this.rdbtnMasc.TabIndex = 6;
            this.rdbtnMasc.TabStop = true;
            this.rdbtnMasc.Text = "Masculino";
            this.rdbtnMasc.UseVisualStyleBackColor = true;
            // 
            // checkEstadoCivil
            // 
            this.checkEstadoCivil.AutoSize = true;
            this.checkEstadoCivil.Location = new System.Drawing.Point(527, 141);
            this.checkEstadoCivil.Name = "checkEstadoCivil";
            this.checkEstadoCivil.Size = new System.Drawing.Size(62, 17);
            this.checkEstadoCivil.TabIndex = 3;
            this.checkEstadoCivil.Text = "Casado";
            this.checkEstadoCivil.UseVisualStyleBackColor = true;
            // 
            // btnVDesc
            // 
            this.btnVDesc.Location = new System.Drawing.Point(173, 137);
            this.btnVDesc.Name = "btnVDesc";
            this.btnVDesc.Size = new System.Drawing.Size(131, 23);
            this.btnVDesc.TabIndex = 4;
            this.btnVDesc.Text = "Verificar desconto";
            this.btnVDesc.UseVisualStyleBackColor = true;
            this.btnVDesc.Click += new System.EventHandler(this.btnVDesc_Click_1);
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(585, 203);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 0;
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Location = new System.Drawing.Point(192, 238);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliINSS.TabIndex = 0;
            // 
            // txtDescIRRF
            // 
            this.txtDescIRRF.Enabled = false;
            this.txtDescIRRF.Location = new System.Drawing.Point(585, 229);
            this.txtDescIRRF.Name = "txtDescIRRF";
            this.txtDescIRRF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRRF.TabIndex = 0;
            // 
            // txtAliIRRF
            // 
            this.txtAliIRRF.Enabled = false;
            this.txtAliIRRF.Location = new System.Drawing.Point(192, 264);
            this.txtAliIRRF.Name = "txtAliIRRF";
            this.txtAliIRRF.Size = new System.Drawing.Size(100, 20);
            this.txtAliIRRF.TabIndex = 0;
            // 
            // txtSAlFamilia
            // 
            this.txtSAlFamilia.Enabled = false;
            this.txtSAlFamilia.Location = new System.Drawing.Point(192, 290);
            this.txtSAlFamilia.Name = "txtSAlFamilia";
            this.txtSAlFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSAlFamilia.TabIndex = 0;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(192, 316);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiquido.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(99, 319);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Salário Líquido";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(111, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "label11";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(501, 309);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(80, 23);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnOut
            // 
            this.btnOut.Location = new System.Drawing.Point(605, 309);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(80, 23);
            this.btnOut.TabIndex = 4;
            this.btnOut.Text = "Sair";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 484);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnOut);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnVDesc);
            this.Controls.Add(this.checkEstadoCivil);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSAlFamilia);
            this.Controls.Add(this.txtAliIRRF);
            this.Controls.Add(this.txtDescIRRF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtNFilhos);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.txtNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox txtNome;
        private System.Windows.Forms.MaskedTextBox txtSalBruto;
        private System.Windows.Forms.MaskedTextBox txtNFilhos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtnFem;
        private System.Windows.Forms.RadioButton rdbtnMasc;
        private System.Windows.Forms.CheckBox checkEstadoCivil;
        private System.Windows.Forms.Button btnVDesc;
        private System.Windows.Forms.MaskedTextBox txtDescINSS;
        private System.Windows.Forms.MaskedTextBox txtAliINSS;
        private System.Windows.Forms.MaskedTextBox txtDescIRRF;
        private System.Windows.Forms.MaskedTextBox txtAliIRRF;
        private System.Windows.Forms.MaskedTextBox txtSAlFamilia;
        private System.Windows.Forms.MaskedTextBox txtSalLiquido;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnOut;
    }
}

