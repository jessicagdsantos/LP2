﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Globalization;

namespace P0030482013032
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            string input;
            double[,] vendas = new double[2, 4];
            double totalSemana;
            double totalMês;
            double totalGeral;


            for (int i = 0; i < 2; i++)
            {

                for (int j = 0; j < 4; j++)
                {

                    while (true)
                    {
                        input = Interaction.InputBox($"Digite o  total de vendas da semana {j + 1} do mês {i + 1}");
                        if (double.TryParse(input, out vendas[i, j]))
                        {
                            break;
                        }
                        MessageBox.Show("Valor inválido. Digite novamente!!!");


                    }

                }


            }
            totalGeral = 0;

            for (int i = 0; i < 2; i++)
            {

                totalMês = 0;
                for (int j = 0; j < 4; j++)
                {

                    totalSemana = vendas[i, j];

                    totalMês = totalMês + totalSemana;

                    listResult.Items.Add($"Total do mês: {i + 1} Semana: {j + 1} {totalSemana.ToString("C", CultureInfo.CurrentCulture)}");
                }

                totalGeral = totalGeral + totalMês;

                listResult.Items.Add($">> Total Mês:  {totalMês.ToString("C", CultureInfo.CurrentCulture)}");

                listResult.Items.Add("--------------------------------------");

            }
            listResult.Items.Add($">> Total Geral:  {totalGeral.ToString("C", CultureInfo.CurrentCulture)}");
        }
    }

}