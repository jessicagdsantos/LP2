﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMETODOSEMENUS
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chamou o copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chamou o colar");

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close(); 

        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Para formulário não ficar abrindo um atrás do outro ao clicar
            Form fc = Application.OpenForms["frmExercicio2"];
            if (fc != null)
                fc.Close();

            // Criação de objeto para classe
            frmExercicio2 FrmExercicio2 = new frmExercicio2();
            // this para objeto em questão. Pai é o form principal
            FrmExercicio2.MdiParent = this;
            // abrir maximizado
            FrmExercicio2.WindowState = FormWindowState.Maximized;
            FrmExercicio2.Show();


        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Para formulário não ficar abrindo um atrás do outro ao clicar
            Form fc = Application.OpenForms["frmExercicio3"];
            if (fc != null)
                fc.Close();

            // Criação de objeto para classe
            frmExercicio3 FrmExercicio3 = new frmExercicio3();
            // this para objeto em questão. Pai é o form principal
            FrmExercicio3.MdiParent = this;
            // abrir maximizado
            FrmExercicio3.WindowState = FormWindowState.Maximized;
            FrmExercicio3.Show();

        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Para formulário não ficar abrindo um atrás do outro ao clicar
            Form fc = Application.OpenForms["frmExercicio4"];
            if (fc != null)
                fc.Close();

            // Criação de objeto para classe
            frmExercicio4 FrmExercicio4 = new frmExercicio4();
            // this para objeto em questão. Pai é o form principal
            FrmExercicio4.MdiParent = this;
            // abrir maximizado
            FrmExercicio4.WindowState = FormWindowState.Maximized;
            FrmExercicio4.Show();

        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Para formulário não ficar abrindo um atrás do outro ao clicar
            Form fc = Application.OpenForms["frmExercicio5"];
            if (fc != null)
                fc.Close();

            // Criação de objeto para classe
            frmExercicio5 FrmExercicio5 = new frmExercicio5();
            // this para objeto em questão. Pai é o form principal
            FrmExercicio5.MdiParent = this;
            // abrir maximizado
            FrmExercicio5.WindowState = FormWindowState.Maximized;
            FrmExercicio5.Show();


        }
    }
}
