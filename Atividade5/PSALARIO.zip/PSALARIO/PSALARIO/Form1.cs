﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSALARIO
{
    public partial class Form1 : Form
    {
        double salBruto, descontoINSS, aliquota, descontoIRRF, salFamilia, salLiquido;
        int filhos;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAliINSS.Clear();
            txtAliIRRF.Clear();
            txtDescINSS.Clear();
            txtDescIRRF.Clear();
            txtNFilhos.Clear();
            txtNome.Clear();
            txtSalBruto.Clear();
            txtSAlFamilia.Clear();
            txtSalLiquido.Clear();

        }


        private void btnVDesc_Click_1(object sender, EventArgs e)
        {
            //Verificação dos campos de nome, salário e quantidade de filhos

            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome deve ser preenchido!!!");
                return;
            }

            if (!double.TryParse(txtSalBruto.Text, out salBruto))
            {
                MessageBox.Show("Valor de salário bruto inválido!!!");
                return;

            }

            if (!int.TryParse(txtNFilhos.Text, out filhos))
            {
                MessageBox.Show("Quantidade de filhos inválida!");
                return;
            }

            //   double descINSS;
            double descontoIRRF;
            double salFamilia;

            descontoINSS = CalcularINSS(salBruto);
            descontoIRRF = CalcularIRRF(salBruto);
            salFamilia = CalcularSalFamilia(salBruto, filhos);

            double salLiquido = salBruto + salFamilia - descontoINSS - descontoIRRF;

            txtSalLiquido.Text = salLiquido.ToString("N2");

            
        }

        private double CalcularINSS(double salBruto)
        {
            double aliquota = 0;

            if (salBruto <= 800.47)
            {
                aliquota = 0.075;
            }
            else if (salBruto <= 1050)
            {
                aliquota = 0.0865;
            }
            else if (salBruto <= 1400.77)
            {
                aliquota = 0.09;
            }
            else if (salBruto <= 2901.56)
            {
                aliquota = 0.11;
            }
            else
            {
                aliquota = 0;
            }

            txtAliINSS.Text = aliquota.ToString("P");

            // Desconto alíquota INSS 

            double desconto;
            if (aliquota == 0)
            {
                desconto = 308.17;
            }
            else
            {
                desconto = salBruto * aliquota;
            }

            txtDescINSS.Text = desconto.ToString("N2");

            return desconto;
        }

        private double CalcularIRRF(double salBruto)
        {
            double aliquota;

            if (salBruto <= 1257.12)
            {
                aliquota = 0;
            }
            else if (salBruto <= 2512.08)
            {
                aliquota = 0.15;
            }
            else
            {
                aliquota = 0.275;
            }

            txtAliIRRF.Text = aliquota.ToString("P");

            // Calcular desconto IRRF

            double desconto;
            if (aliquota == 0)
            {
                desconto = 0;
            }
            else
            {
                desconto = salBruto * aliquota;
            }

            txtDescIRRF.Text = desconto.ToString("N2");

            return desconto;
        }

        private double CalcularSalFamilia(double salBruto, int filhos)
        {
            double salFamilia;

            if (salBruto <= 453.52)
            {
                salFamilia = 22.33;
            }
            else if (salBruto <= 654.61)
            {
                salFamilia = 15.74;
            }
            else
            {
                salFamilia = 0;
            }

            salFamilia = salFamilia * filhos;

            txtSAlFamilia.Text = salFamilia.ToString("N2");

            return salFamilia;
        }
    }
        
    
}

