﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSALARIO
{
    public partial class Form1 : Form
    {
        double salBruto, descontoInss, aliquota, descontoIRRF, salFamilia, salLiquido;
        int filhos;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnOut_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAliINSS.Clear();
            txtAliIRRF.Clear();
            txtDescINSS.Clear();
            txtDescIRRF.Clear();
            txtNFilhos.Clear();
            txtNome.Clear();
            txtSalBruto.Clear();
            txtSAlFamilia.Clear();
            txtSalLiquido.Clear();

        }


        private void btnVDesc_Click_1(object sender, EventArgs e)
        {
            //Verificação dos campos de nome, salário e quantidade de filhos

            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome deve ser preenchido!!!");
                return;
            }

            if (!double.TryParse(txtSalBruto.Text, out salBruto))
            {
                MessageBox.Show("Valor de salário bruto inválido!!!");
                return;

            }

            if (!int.TryParse(txtNFilhos.Text, out filhos))
            {
                MessageBox.Show("Quantidade de filhos inválida!");
                return;
            }

            //Verificar desconto do INSS 
            if (salBruto <= 800.47)
            {
                descontoInss = salBruto * (7.65 / 100);
                txtDescINSS.Text = descontoInss.ToString();
                txtAliINSS.Text = 7.65.ToString();
            }
            if (salBruto > 800.48 && salBruto <= 1050)
            {
                descontoInss = salBruto * (8.65 / 100);
                txtDescINSS.Text = descontoInss.ToString();
                txtAliINSS.Text = 8.65.ToString();
            }
            if (salBruto >= 1050.01 && salBruto <= 1400.77)
            {
                descontoInss = salBruto * (9.00 / 100);
                txtDescINSS.Text = descontoInss.ToString();
                txtAliINSS.Text = 9.ToString();
            }
            if (salBruto >= 1400.78 && salBruto <= 2801.56)
            {
                descontoInss = salBruto * (11 / 100);
                txtDescINSS.Text = descontoInss.ToString();
                txtAliINSS.Text = 11.ToString();
            }
            if (salBruto > 2801.56)
            {
                descontoInss = salBruto - 308.17;
                txtDescINSS.Text = descontoInss.ToString();
            }

            //Verificar desconto IRRF
            if (salBruto <= 1257.12)
            {
                descontoIRRF = 0;
                txtDescIRRF.Text = descontoIRRF.ToString();
                txtAliIRRF.Text = 0.ToString();
            }
            if (salBruto > 1257.12 && salBruto <= 2512.08)
            {
                descontoIRRF = salBruto * (15 / 100);
                txtDescIRRF.Text = descontoIRRF.ToString();
                txtAliIRRF.Text = 15.ToString();
            }
            if (salBruto > 2512.08)
            {
                descontoIRRF = salBruto * (27.5 / 100);
                txtDescIRRF.Text = descontoIRRF.ToString();
                txtAliIRRF.Text = 27.5.ToString();
            }
            //Verificar Salário Família
            if (salBruto < 435.52)
            {
                int.TryParse(txtNFilhos.Text, out filhos);
                salFamilia = 22.33 * filhos;
                txtSAlFamilia.Text = salFamilia.ToString();
                

            }
            else if (salBruto >= 435.52 && salBruto <= 654.61)
            {
                int.TryParse(txtNFilhos.Text, out filhos);
                salFamilia = 15.74 * filhos;
                txtSAlFamilia.Text = salFamilia.ToString();
            }
            else
            {
                salFamilia = 0 * filhos;
                txtSAlFamilia.Text = salFamilia.ToString();
            }
        }
    }
}

