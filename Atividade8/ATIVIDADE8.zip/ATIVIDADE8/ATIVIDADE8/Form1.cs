﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ATIVIDADE8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];
            string numInvertido="";

            for (int i = 0; i < 20; i++)
            {

                string input = Interaction.InputBox($"Escreva um número {i+1}/20");

                if (!(int.TryParse(input,out numeros[i])))
                    {
                    i--;
                    MessageBox.Show("Valor inválido");
                    }

            }
            for (int i=19; i>=0; i--)
            {
                numInvertido = $"{numInvertido} {numeros[i]}";


            }
            MessageBox.Show(numInvertido);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];
            string numInvertido = "";

            for (int i = 0; i < 20; i++)
            {

                string input = Interaction.InputBox($"Escreva um número {i + 1}/20");

                if (!(int.TryParse(input, out numeros[i])))
                {
                    i--;
                    MessageBox.Show("Valor inválido");
                }

            }
                Array.Reverse(numeros);
            numInvertido = String.Join(" ", numeros);
            MessageBox.Show(numInvertido);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        { 
                string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

                int total = 0;

                for (int i = 0; i < Alunos.Length - 1; i++)
                {
                    total += Alunos[i].Length;
                }

                MessageBox.Show(total.ToString());
            
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            ArrayList arr = new ArrayList();

            arr.Add("Ana");
            arr.Add("André");
            arr.Add("Débora");
            arr.Add("Fátima");
            arr.Add("João");
            arr.Add("Janete");
            arr.Add("Otávio");
            arr.Add("Marcelo");
            arr.Add("Pedro");
            arr.Add("Thais");

            arr.Remove("Otávio");

            string texto = "";

            for (int i = 0; i < arr.Count; i++)
            {
                texto += arr[i] + "\n";
            }

            MessageBox.Show(texto);
        }
    }
}
